import { User } from './user.model';

describe('User', () => {
  it('should create an instance', () => {
    expect(new User()).toBeTruthy();
  });

  it('should have id as a number ', () => {
    let user: User = new User();
  });
});
