import { Injectable } from '@angular/core';
import { User } from 'src/app/user.model';

@Injectable({
  providedIn: 'root'
})
export class FooServiceService {

  constructor() { }

  checkIfUserIsFoo(user_name: string) {
    return user_name === "foo";
  }
}
