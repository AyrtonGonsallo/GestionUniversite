import { Injectable } from '@angular/core';
import { Address } from 'src/app/address.model';
import { User } from 'src/app/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  public user: User;

  constructor() {
    this.user = new User();
    this.user.name = "OUTAMA Othmane";
    this.user.email = "outama.othmane@gmail.com";
    this.user.phone = "+212639385987";
    this.user.password = "password";
    this.user.address = new Address();
    this.user.address.numero = 4;
    this.user.address.rue = "Tagadirt";
    this.user.address.ville = "Agadir";
    this.user.address.pays = "Maroc";
  }

  public getUser(): User {
    return this.user;
  }

  public updateUser(user: User): void {
    this.user = user;
  }
}
