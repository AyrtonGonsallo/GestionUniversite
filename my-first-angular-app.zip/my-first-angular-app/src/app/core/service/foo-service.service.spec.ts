import { TestBed } from '@angular/core/testing';

import { FooServiceService } from './foo-service.service';

describe('FooServiceService', () => {
  let service: FooServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FooServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
