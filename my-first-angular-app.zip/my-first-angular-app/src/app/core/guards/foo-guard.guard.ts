import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from 'src/app/user.model';
import { FooServiceService as FooService } from '../service/foo-service.service';

@Injectable({
  providedIn: 'root'
})
export class FooGuardGuard implements CanActivate {
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    let result = this.fooService.checkIfUserIsFoo(this.user);
    if (!result) this.router.navigate(["/404"]);
    return result;
  }

  constructor(private fooService: FooService, private router: Router) {

  }

  public get user(): string {
    return localStorage.getItem("user-name") ?? "";
  }
  
}
