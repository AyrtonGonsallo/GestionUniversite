import { TestBed } from '@angular/core/testing';

import { FooGuardGuard } from './foo-guard.guard';

describe('FooGuardGuard', () => {
  let guard: FooGuardGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(FooGuardGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
