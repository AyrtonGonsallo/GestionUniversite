import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'numberToLetters'
})
export class NumberToLettersPipe implements PipeTransform {

  transform(value: number): string {
    return "null";
  }

}
