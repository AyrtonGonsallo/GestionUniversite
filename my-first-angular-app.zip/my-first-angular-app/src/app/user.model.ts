import { Address } from "./address.model";

export class User {
    public name: string = "";
    public phone: string = "";
    public email: string = "";
    public password: string = "";
    public address: Address = new Address();

    constructor() {

    }

    /**
     * toString
     */
    public toString() {
        return `{
            name:       ${this.name},
            phone:      ${this.phone},
            email:      ${this.email},
            password:   ${this.password},
            address:   ${this.address},
        }`
    }
}
