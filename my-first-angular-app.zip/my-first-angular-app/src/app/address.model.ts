export class Address {
    public numero: number = 0;
    public rue: string = "";
    public ville: string = "";
    public pays: string = "";

    public toString() {
        return `[numero=${this.numero}, rue=${this.rue}, ville=${this.ville}, pays=${this.pays}]`;
    }
}
