import { Component, Input, OnInit } from '@angular/core';
import { UserServiceService as UserService } from '../core/service/user-service.service';
import { User } from '../user.model';


@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit {

  @Input('myTitle')
  title: string;

  constructor(private userService: UserService) {
    this.title = "";

  }

  public get user(): User {
    return this.userService.getUser();
  }

  ngOnInit(): void {
  }

}
