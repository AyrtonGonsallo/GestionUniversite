import { Pipe, PipeTransform } from '@angular/core';
import { Address } from './address.model';

@Pipe({
  name: 'address'
})
export class AddressPipe implements PipeTransform {

  transform(value: Address): string {
    return `FROM AddressPipe, ${value.toString()}`;
  }

}
