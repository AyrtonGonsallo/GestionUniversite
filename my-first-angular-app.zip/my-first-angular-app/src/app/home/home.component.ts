import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Address } from '../address.model';
import { UserServiceService as UserService } from '../core/service/user-service.service';
import { User } from '../user.model';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  @Input('myTitle')
  title: string;

  @Input()
  item = "";

  @Output()
  newItemEvent = new EventEmitter<string>();
  
  constructor(private userService: UserService) {
    this.title = "";
    
  }

  public get user(): User {
    return this.userService.user;
  }

  public set user(user: User) {
    this.userService.user = user;
  }

  public updateUser(name: string): void {
    let user: User = new User();
    
    user.name = name;
    user.email = this.user.email;
    user.phone = this.user.phone;
    user.password = this.user.password;
    user.address = this.user.address;

    this.user = user;
  }

  addNewItem(value:string) {
    this.newItemEvent.emit(value);
  }

  ngOnInit(): void {
  }

}
