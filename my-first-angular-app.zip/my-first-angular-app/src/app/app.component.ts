import { Component, Input } from '@angular/core';
import { TestService } from './core/service/test.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  titleForHome = 'my-home';
  titleForAbout = 'my-about';

  currentItem = 'Television';
  
  items = ['item1', 'item2'];

  // newTitle: string="";

  constructor(private testService:TestService) {
    localStorage.setItem("user-name", "foo")
  }
  
  public addItem(newItem: string) {
    this.items.push(newItem);
  }
}
