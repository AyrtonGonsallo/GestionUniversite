package com.nejeoui.jadetd.model;

import com.nejeoui.jadetd.ProductStatus;

public class Product {
private String reference;
private String name;
private String description;
private double price;
private ProductStatus status;
public String getReference() {
	return reference;
}
public void setReference(String reference) {
	this.reference = reference;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public ProductStatus getStatus() {
	return status;
}
public void setStatus(ProductStatus status) {
	this.status = status;
}

}
