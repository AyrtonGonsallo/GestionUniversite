package com.nejeoui.jadetd;

import java.util.List;

import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.google.gson.*;
import com.nejeoui.jadetd.model.Product;

public class ProductParser {

	public static List<Product> fromJson(String productsJson) {
		GsonBuilder builder = new GsonBuilder();
		Gson gson = builder.create();
		
		return gson.fromJson(productsJson, new TypeToken<List<Product>>() {
		}.getType());
	}
	
	public static String toJson(List<Product> products) {
		GsonBuilder builder = new GsonBuilder();
		Gson gson = builder.create();
		
		return gson.toJson(products);
	}
	
	public static void main(String[] args) {
		String prodJson="""
[
{
	'reference':'pr007',
	'name':'ProdName007',
	'description':'Pr007 Description',
    'price':127.60,
    'status':'AVAILABLE'
},
{
	'reference':'pr0056',
	'name':'ProdName0056',
	'description':'Pr0056 Description',
    'price':560.90,
    'status':'AVAILABLE'
},
{
	'reference':'pr0043',
	'name':'ProdName0043',
	'description':'Pr0043 Description',
    'price':44.55,
    'status':'AVAILABLE'
}
]
				""";
		System.out.println(fromJson(prodJson).get(2).getPrice());
		System.out.println(fromJson(prodJson).get(1).getPrice());
	}

}
