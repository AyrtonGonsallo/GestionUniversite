package com.nejeoui.jadetd;

public enum ProductStatus {
	AVAILABLE,SOLD

}
