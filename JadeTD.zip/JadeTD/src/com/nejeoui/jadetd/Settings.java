package com.nejeoui.jadetd;

public class Settings {
	public static String ReceiveRequestAgentGID="";
	public static String ReceiveRequestResponseAgentGID="";
	public static String SetupFeesVerificationGID="";
	public static String ReceiveCredentialsAgentGID="";
	public static String buyerAgentGID="";
	public static Object monitor=new Object();

}
