package com.nejeoui.jadetd.dao;

import java.util.List;

import com.nejeoui.jadetd.model.Product;

public class ProductDaoImpl {

	public void updateProduct(Product product) {
		
		
	}

	public List<Product> select3AvailableProducts() {
		// TODO Auto-generated method stub
		return null;
	}

}
