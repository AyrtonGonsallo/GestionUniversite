package com.nejeoui.jadetd;


import java.util.List;
import java.util.logging.Logger;

import com.nejeoui.jadetd.dao.ProductDaoImpl;
import com.nejeoui.jadetd.model.Product;

import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.CyclicBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class BuyerAgent extends Agent {
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void setup() {
		DFAgentDescription template = new DFAgentDescription();
		template.setName(getAID());
		ServiceDescription agentDescriptor = new ServiceDescription();
		agentDescriptor.setType("BuyerAgent");
		agentDescriptor.setName(getLocalName() + "BuyerAgent");
		template.addServices(agentDescriptor);
		try {
			DFService.register(this, template);
		} catch (FIPAException fe) {
			fe.printStackTrace();
		}
       final long timer=System.currentTimeMillis();
		Behaviour updateResourcesBehaviour = new CyclicBehaviour() {

			@Override
			public void action() {
				MessageTemplate temp = MessageTemplate.MatchPerformative(ACLMessage.INFORM);
				ACLMessage aclMeessage = receive(temp);
				if (aclMeessage != null) {
					String productsJson = aclMeessage.getContent();
					
					List<Product> productList = ProductParser.fromJson(productsJson);
					if (productList != null && productList.size() > 0) {
						new ProductDaoImpl().updateProduct(productList.get(0));
					}
				}
				//block waiting for new resources
				block();
			}
		};
		addBehaviour(updateResourcesBehaviour);

	}
}
